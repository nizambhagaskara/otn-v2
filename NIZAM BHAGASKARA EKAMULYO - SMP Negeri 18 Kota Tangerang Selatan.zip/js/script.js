document.addEventListener('DOMContentLoaded', () => {
  const dropdownMenu = document.querySelector('.dropdown-menu');
  const toggleBtn = document.querySelector('.toggle-btn');
  let toggleBtnClickCount = 0;

  // Close dropdown when a nav link is clicked
  const navLinks = document.querySelectorAll('.dropdown-menu a');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeDropdown();
    });
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    const isClickInside = dropdownMenu.contains(e.target) || toggleBtn.contains(e.target);
    if (!isClickInside && !dropdownMenu.classList.contains('hidden')) {
      closeDropdown();
    }
  });

  // Reuse your show/hide logic in a function
  function closeDropdown() {
    toggleBtn.classList.remove('opened');
    dropdownMenu.classList.replace('opacity-100', 'opacity-0');
    dropdownMenu.addEventListener('transitionend', () => {
      dropdownMenu.classList.add('hidden');
    }, { once: true });
  }

  function enableWobbler() {
    const userInput = prompt("Enter class name:");
    if (userInput == "wigglywobble") {
      document.body.classList.add('wigglywobble');
    }
  }

  function toggleDropdown() {
    toggleBtn.classList.toggle('opened');
    if (dropdownMenu.classList.contains('hidden')) {
      dropdownMenu.classList.remove('hidden');
      requestAnimationFrame(() => {
        dropdownMenu.classList.replace('opacity-0', 'opacity-100');
      });
    } else {
      dropdownMenu.classList.replace('opacity-100', 'opacity-0');
      dropdownMenu.addEventListener('transitionend', () => {
        dropdownMenu.classList.add('hidden');
      }, { once: true });
    }
    toggleBtnClickCount++;
    if (toggleBtnClickCount == 50) enableWobbler();
  }

  toggleBtn.addEventListener('click', toggleDropdown);

  function setActiveLink(id) {
    if (!id) return;
    // remove active from all li.nav-links
    document.querySelectorAll('.nav-links').forEach(li => li.classList.remove('active'));

    const anchors = document.querySelectorAll(`a[href="#${id}"]`);

    anchors.forEach(a => {
      const li = a.closest('.nav-links');
      if (li) li.classList.add('active');
    });
  }

  const sections = document.querySelectorAll('section');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      const id = entry.target.getAttribute('id');
      if (entry.isIntersecting) {
        window.history.replaceState(null, null, `#${id}`);
        setActiveLink(id);
      }
    });
  }, {threshold: 0.2});

  sections.forEach(section => observer.observe(section));

  // Handle special case when at the very top (home)
  function handleHomeLink() {
    if (window.scrollY === 0) {
      window.history.replaceState(null, null, '#home');
      setActiveLink('home');
    }
  }

  // initial activation (on load)
  const initialHash = location.hash ? location.hash.replace('#', '') : 'home';
  setActiveLink(initialHash);
  handleHomeLink();

  // header scrolled class
  const header = document.getElementById("mainHeader");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 0) header.classList.add("scrolled");
    else header.classList.remove("scrolled");

    handleHomeLink();

    // close dropdown on scroll
    if (!dropdownMenu.classList.contains('hidden')) {
      closeDropdown();
    }
  });

  // wobbler on pc
  document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      enableWobbler();
    }
  });

  console.log("Ctrl + Shift + K -> wigglywobble");
  console.log("do it :)");

  const wobblemobile = document.querySelector('.wobblemobile');
  const wobbleRng = Math.floor(Math.random() * (67 + 1)); // SIX SEVENNNNNNNNNNN
  if (wobbleRng === 67) {
    wobblemobile.classList.remove("hidden");
    wobblemobile.classList.add("flex");
  }

  document.querySelectorAll('.delay').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();

      // Add inward bounce
      el.classList.add('bounce-inward');

      // Remove the class after animation ends
      setTimeout(() => {
        el.classList.remove('bounce-inward');
      }, 300);

      // Redirect after a short delay
      const url = el.href;
      setTimeout(() => {
        window.open(url, el.target || '_self');
      }, 500); // 0.5s delay before redirect
    });
  });

  // Message form handling
  const msgForm = document.getElementById('MsgForm');

  msgForm.addEventListener("submit", function(e) {
    e.preventDefault();
    const msgName = document.getElementById('MsgName').value.trim();
    const msgText = document.getElementById('MsgText').value.trim();

    const readyToSend = encodeURI(`Hi, my name is ${msgName}. \n\n${msgText}`);
    const waLink = `https://wa.me/6287785752761?text=${readyToSend}`;
    window.open(waLink, '_blank');
  });
  
  // Select all scroll-animation elements
  const scrollElements = document.querySelectorAll(
    '.scroll-up, .scroll-left, .scroll-right'
  );

  // IntersectionObserver to trigger animation when element is in viewport
  const animObserver = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry, index) => {
        if (!entry.isIntersecting) return;

        const el = entry.target;

        el.style.transitionDelay = `${index * 80}ms`;

        el.classList.add('show');   // add class to animate
        obs.unobserve(el);          // stop observing once animated
      });
    },
    { threshold: 0.15 }  // trigger when 15% of element is visible
  );

  // Observe all scroll elements
  scrollElements.forEach(el => animObserver.observe(el));
});